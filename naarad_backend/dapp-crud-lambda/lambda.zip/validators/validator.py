class Validator:
    def validate(self, user, api_input):
        raise NotImplementedError
